import { Home as HomeContainer } from 'containers'

export default function Home() {
    return <HomeContainer />
}
